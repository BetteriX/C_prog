* Ezt a könyvtárat majd nevezzék át
  a saját nevükre, és írják be a Neptun-kódjukat is!

  Az egyes részeket aláhúzásjellel válasszák el!
  A könyvtár nevében NE használjanak ékezeteket!

* Mit lehet használni?

  - saját, kézzel írt jegyzet
  - CS50 dokumentáció
  - 2 oldalas C cheat sheet (ha előre kinyomtatták)
  - mellékelt prog1 library
  - mellékelt asciichart.png

  Minden egyéb eszköz használata meg nem engedett segédeszköznek minősül.

* Tilos egymással kommunikálni a ZH ideje alatt.
  A saját, egyéni teljesítményükre vagyok kíváncsi.

* Meg nem engedett segédeszköz használata esetén a dolgozatra
  0 pontot kapnak.

* Az egyes feladatokat itt, ebben a könyvtárban kell kidolgozni!
  A mellékelt üres feladatN.c állományok tartalmát írják meg.

* Minden egyes feladat megoldása kész, komplett, minden mástól
  független megoldás legyen. Minden egyes feladat
  egyszerűen fordítható és futtatható legyen.

  Példa:

  $ gcc feladatN.c    # lefordul
  $ ./a.out           # lefut

* Ha kész vannak, akkor majd ezt a könyvtárat kell
  becsomagolni ZIP-be és feltölteni a Moodle oldalra.

  A lefordított, bináris állományokat (pl. a.out) NEM kell feltölteni!

  Vigyázzon, nehogy a forráskódokat törölje le!

* Miután elküldték a megoldást, utólagos javításra már nincs lehetőség!
  Amit először elküldtek, azt fogom kijavítani.
